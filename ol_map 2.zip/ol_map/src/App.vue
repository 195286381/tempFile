<template>
  <div class="container">
    <div id="map" class="map" />

    <div id="popup" class="olPopup" ref="popup">
      <div style="text-align: right;">
        <div style="text-align: left; float: left; color: white; font-weight: 700;" >属性列表</div> <span @click="overlayer.setPosition(undefined)" class="popupClose">X</span>
      </div>
      <div id="popup-content" ref="popupContent"></div>
    </div>

    <h2>底图切换</h2>
    <div class="line">
      <button @click="change_img">切换天地图影像底图</button>
      <button @click="change_vec">切换天地图矢量底图</button>
    </div>

    <h2>图层绘制</h2>
    <div class="line">
      <label>绘制类型: </label>
      <select id="type" v-model="drawType">
        <option value="Point">点</option>
        <option value="LineString">线</option>
        <option value="Polygon">多边形</option>
        <option value="Circle">圆</option>
      </select>
      <button @click="addInteraction">开启绘制</button>
      <button @click="removeInteraction">关闭绘制</button>
    </div>
  </div>
</template>

<script>
import 'ol/ol.css'
import Map from 'ol/Map'
import View from 'ol/View'
import TileLayer from 'ol/layer/Tile'
import XYZ from 'ol/source/XYZ'
import {fromLonLat} from 'ol/proj.js';
import VectorSource from "ol/source/Vector";
import VectorLayer from "ol/layer/Vector";
import {Fill, Stroke, Style} from "ol/style";
import CircleStyle from "ol/style/Circle";
import {Draw, Select, Snap} from "ol/interaction";
import {Overlay} from "ol";
import { altKeyOnly, click, pointerMove } from "ol/events/condition";
export default {
  name: 'app',
  data () {
    return {
      map: null,
      map_img:null,
      map_vec:null,
      map_cva:null,
      draw_source: null,
      map_draw: null,
      drawType: 'Point',
      select: null
    }
  },
  mounted () {
    this.init_map()
    this.init_map_overlay()
  },

  methods:{
    init_map() {

      // 天地图标注图层
      this.map_cva = new TileLayer({
        source: new XYZ({
          url: "http://t3.tianditu.com/DataServer?T=cva_w&x={x}&y={y}&l={z}&tk=d0cf74b31931aab68af181d23fa23d8d"
        })
      })

      // 天地图影像
      this.map_img = new TileLayer({
        source: new XYZ({
          url:  'http://t3.tianditu.com/DataServer?T=img_w&x={x}&y={y}&l={z}&tk=d0cf74b31931aab68af181d23fa23d8d'
        })
      })

      // 天地图矢量
      this.map_vec = new TileLayer({
        source: new XYZ({
          url: "http://t4.tianditu.com/DataServer?T=vec_w&x={x}&y={y}&l={z}&tk=d0cf74b31931aab68af181d23fa23d8d"
        })
      })

      // 绘制的矢量图层
      this.draw_source = new VectorSource();
      this.map_draw = new VectorLayer({
        source: this.draw_source,
        style: new Style({
          fill: new Fill({
            color: 'rgba(255, 255, 255, 0.2)',
          }),
          stroke: new Stroke({
            color: '#ffcc33',
            width: 2,
          }),
          image: new CircleStyle({
            radius: 7,
            fill: new Fill({
              color: '#ffcc33',
            }),
          }),
        }),
      });




      // 视图
      var view =new View({
        center: fromLonLat([116.40969,39.89945]),
        zoom: 8
      })


      // 地图
      this.map = new Map({
        target: 'map',
        layers: [
            this.map_vec,
            this.map_img,
            this.map_cva,
            this.map_draw
        ],
        view: view
      })
    },

    init_map_overlay() {
      const overlayer = new Overlay({
        element: this.$refs.popup,
        autuPan: true
      });
      const select = new Select({
        condition: click
      });

      this.map.addInteraction(select)
      select.on('select', e => {
            if (e.selected.length != 0) {
              // 当前点的坐标
              var coordinate = e.mapBrowserEvent.coordinate;
              // 当前点的属性信息
              var properties = e.selected[0].getProperties();
              // 将信息填入弹出框
              this.$refs.popupContent.innerHTML =
                  `
                  <div>名称：${properties.name}</div>
                  <br>
                  <div>类别：${properties.type}</div>
                    <br>
                  <div>备注：${properties.remark}</div>
                `
              // 调整overlayer层的位置
              overlayer.setPosition(coordinate);
              // 将overlayer层添加到map当中
              this.map.addOverlay(overlayer);
            } else {
              overlayer.setPosition(undefined);
            }
            this.overlayer = overlayer
     }  )

      this.select = select
    },


    // 开始交互绘制
    addInteraction() {
      this.map.removeInteraction(this._draw)
      this.map.removeInteraction(this._snap)
      // 绘制交互
      this._draw = new Draw({
        source: this.draw_source,
        type: this.drawType
      });

      this._draw.on('drawend', e => {
        const name = window.prompt("输出入矢量名称:")
        const type = window.prompt("请输入矢量类别:")
        const remark = window.prompt("请入备注信息:")
        const properties = {
          name,
          type,
          remark
        }
        e.feature.setProperties(properties)

      })

      this._snap = new Snap({source: this.draw_source});

      this.map.addInteraction(this._draw);
      this.map.addInteraction(this._snap);
      this.map.removeInteraction(this.select)
    },

    // 停止交互绘制
    removeInteraction() {
      this.map.removeInteraction(this._draw)
      this.map.removeInteraction(this._snap)
      this.map.addInteraction(this.select)

    },


    change_img (){
      this.map_img.setVisible(true)
      this.map_vec.setVisible(false)
    },
    change_vec(){
      this.map_img.setVisible(false)
      this.map_vec.setVisible(true)
    },
  }

}
</script>

<style>
html, body {
  height: 100%;
}
.container {
  height: 100%;
}

.map{
  width: 100%;
  height:70%;
}

.olPopup {
  position: absolute;
  background-color: rgba(47, 57, 90, 0.678);
  padding: 15px;
  color: white;
  border-radius: 10px;
  border: 1px solid #cccccc;
  bottom: 20px;
  left: 30px;
  min-width: 280px;


}

.popupClose {
  cursor: pointer;
}

.popupClose:hover {
  color: rgba(255, 255, 255, 0.719);
}

.line {
  margin: 2px;
}
</style>
